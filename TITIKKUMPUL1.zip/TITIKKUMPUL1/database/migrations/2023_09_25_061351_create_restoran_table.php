<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('restoran', function (Blueprint $table) {
            $table->id();
            $table->string('nama_restoran', 50);
            $table->string('jenis_makanan', 20);
            $table->string('menu', 30);
            $table->text('deskripsi');
            $table->string('lokasi', 50);    
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('restoran');
    }
};
